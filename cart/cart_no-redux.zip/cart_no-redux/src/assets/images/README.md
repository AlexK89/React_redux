# Images

If you want to use any images, webpack will compile them from here...

You can reference this directory using the alias `'@images'`, like so:

```
import trump from '@images/trump.jpg'
```
