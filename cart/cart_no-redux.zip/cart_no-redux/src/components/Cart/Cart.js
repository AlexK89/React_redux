import React, {Component} from 'react';
import OrderList from './OrderList/OrderList';

class Cart extends Component {
    state = {
        orderList: [
            {
                id: 1,
                label: 'iPhone',
                quantity: 0,
                price: 999,
                totalProductPrice: 0
            },
            {
                id: 2,
                label: 'iPad',
                quantity: 0,
                price: 499,
                totalProductPrice: 0
            },
            {
                id: 3,
                label: 'Macbook',
                quantity: 0,
                price: 999,
                totalProductPrice: 0
            }
        ],
        total: 0
    };

    // Update total sum
    totalPriceUpdate = (orderList) => {
        return Object.keys(orderList).reduce((a, key) => a + orderList[key].totalProductPrice, 0);
    };

    // Update total Price for product
    totalProductPriceUpdate = (quantity, price) => {
        return quantity * price;
    };

    // Update product quantity
    quantityUpdateHandler = (id, quantity) => {
        // Getting product with selected id and save this product into new variable
        const updatedProductId = this.state.orderList.findIndex(product => product.id === id);
        let updatedProduct = {...this.state.orderList[updatedProductId]};

        // Changing quantity for selected product
        const quantityToNum = parseInt(quantity) ? parseInt(quantity) : '';
        updatedProduct.quantity = quantityToNum;

        // Changing totalPrice for selected product
        updatedProduct.totalProductPrice = this.totalProductPriceUpdate(quantityToNum, updatedProduct.price);

        // Create new array of products and update product with selected id
        const newOrderList = [...this.state.orderList];
        newOrderList[updatedProductId] = updatedProduct;

        this.setState({
            orderList: newOrderList,
            total: this.totalPriceUpdate(newOrderList)
        })
    };

    // Remove selected product
    removeProductHandler = (id) => {
        const orderList = [...this.state.orderList];
        const newOrderList = orderList.filter(item => item.id !== id);

        this.setState({
            orderList: newOrderList,
            total: this.totalPriceUpdate(newOrderList)
        });
    };

    //Reset products quantity
    resetQuantityHandler = () => {
        const orderList = [...this.state.orderList];
        let resetOrderList = orderList.map(item => {
            item.quantity = 0;
            item.totalProductPrice = 0;

            return item;
        });

        this.setState({
            orderList: [...resetOrderList],
            total: 0
        });
    };

    render() {
        return (
            <div className="cart">
                <OrderList
                    orderList={this.state.orderList}
                    quantityUpdate={this.quantityUpdateHandler}
                    removeProduct={this.removeProductHandler} />
                <div className="checkout">
                    <p className="checkout__total">$ {this.state.total}</p>
                    <div className="buttons">
                        <button className="buttons__reset" onClick={this.resetQuantityHandler}>Clear</button>
                        <button className="buttons__submit">Check out</button>
                    </div>
                </div>
            </div>
        );
    }
}

export default Cart;