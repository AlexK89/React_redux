import React from 'react';
import closeIcon from '../../../../assets/icons/close.svg';

const OrderListItem = (props) => {
    return (
        <li className="order_list__item">
            <p className="order_list__item__label">{props.listItem.label}</p>
            <div className="order_list__item__input">
                <input type="text"
                       name="quantity"
                       value={props.listItem.quantity}
                       onChange={event => props.quantityUpdate(props.listItem.id, event.target.value)}/>
            </div>
            <div className="order_list__item__price">
                <p>
                    $ {props.listItem.totalProductPrice}
                </p>
                <button onClick={() => props.removeProduct(props.listItem.id)}>
                    <img src={closeIcon} alt="Remove item"/>
                </button>
            </div>
        </li>
    );
};

export default OrderListItem;