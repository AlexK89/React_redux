import React from 'react';
import OrderListItem from './OrderListItem/OrderListItem';

const OrderList = (props) => {
    let list = props.orderList.map(listItem => {
        return <OrderListItem
            key={listItem.id}
            listItem={listItem}
            quantityUpdate={props.quantityUpdate}
            removeProduct={props.removeProduct} />
    });

    return <ul className="order_list">{list}</ul>;
};

export default OrderList;