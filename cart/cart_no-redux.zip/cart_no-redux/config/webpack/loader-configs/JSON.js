module.exports = {
  test: /\.json$/,
  use: 'json-loader'
}
