import * as actionTypes from './actionTypes';

export const quantityUpdate = (id, quantity) => {
    return {
        type: actionTypes.QUANTITY_UPDATE,
        id,
        quantity
    }
};

export const removeProduct = (id) => {
    return {
        type: actionTypes.REMOVE_PRODUCT,
        id,
    }
};

export const resetQuantity = () => {
    return {
        type: actionTypes.RESET_QUANTITY,
    }
};

