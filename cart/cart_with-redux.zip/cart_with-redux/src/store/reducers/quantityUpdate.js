import * as actionTypes from '../actions/actionTypes';

const initialState = {
    orderList: [
        {
            id: 1,
            label: 'iPhone',
            quantity: 0,
            price: 999,
            totalProductPrice: 0
        },
        {
            id: 2,
            label: 'iPad',
            quantity: 0,
            price: 499,
            totalProductPrice: 0
        },
        {
            id: 3,
            label: 'Macbook',
            quantity: 0,
            price: 999,
            totalProductPrice: 0
        }
    ],
    total: 0
};

// Update total sum
const totalPriceUpdate = (orderList) => {
    return Object.keys(orderList).reduce((a, key) => a + orderList[key].totalProductPrice, 0);
};

// Update total Price for product
const totalProductPriceUpdate = (quantity, price) => {
    return quantity * price;
};

const quantityUpdate = (state = initialState, action) => {
    const orderList = [...state.orderList];

    switch (action.type) {
        case actionTypes.QUANTITY_UPDATE:
            // Getting product with selected id and save this product into new variable
            const updatedProductId = state.orderList.findIndex(product => product.id === action.id);
            let updatedProduct = {...state.orderList[updatedProductId]};

            // Changing quantity for selected product
            const quantityToNum = parseInt(action.quantity) ? parseInt(action.quantity) : '';
            updatedProduct.quantity = quantityToNum;

            // Changing totalPrice for selected product
            updatedProduct.totalProductPrice = totalProductPriceUpdate(quantityToNum, updatedProduct.price);

            // Create new array of products and update product with selected id
            const newOrderList = [...state.orderList];
            newOrderList[updatedProductId] = updatedProduct;

            return {
                orderList: [...newOrderList],
                total: totalPriceUpdate(newOrderList)
            };

        case actionTypes.REMOVE_PRODUCT:
            const filteredOrderList = orderList.filter(item => item.id !== action.id);

            return {
                orderList: [...filteredOrderList],
                total: totalPriceUpdate(filteredOrderList)
            };
        case actionTypes.RESET_QUANTITY:
            let resetOrderList = orderList.map(item => {
                item.quantity = 0;
                item.totalProductPrice = 0;

                return item;
            });

            return {
                orderList: [...resetOrderList],
                total: 0
            };
        default:
            return state;
    }
};

export default quantityUpdate;