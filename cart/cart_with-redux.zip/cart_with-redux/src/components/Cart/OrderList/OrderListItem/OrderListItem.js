import React, {Component} from 'react';
import { connect } from 'react-redux';
import * as actions from '../../../../store/actions/index';
import closeIcon from '../../../../assets/icons/close.svg';

export class OrderListItem extends Component {
    render() {
        return (
            <li className="order_list__item">
                <p className="order_list__item__label">{this.props.listItem.label}</p>
                <div className="order_list__item__input">
                    <input type="text"
                           name="quantity"
                           value={this.props.listItem.quantity}
                           onChange={event => this.props.quantityUpdate(this.props.listItem.id, event.target.value)}/>
                </div>
                <div className="order_list__item__price">
                    <p>
                        $ {this.props.listItem.totalProductPrice}
                    </p>
                    <button onClick={() => this.props.removeProduct(this.props.listItem.id)}>
                        <img src={closeIcon} alt="Remove item"/>
                    </button>
                </div>
            </li>
        );
    }
}

// Make global state available in props
const mapStateToProps = state => ({...state});

// Send changed values to global state
const mapDispatchToProps = dispatch => {
    return {
        quantityUpdate: (id, quantity) => dispatch(actions.quantityUpdate(id, quantity)),
        removeProduct: (id) => dispatch(actions.removeProduct(id)),
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderListItem);