import React, {Component} from 'react';
import { connect } from 'react-redux';
import OrderListItem from './OrderListItem/OrderListItem';

export class OrderList extends Component {
    render() {
        let list = this.props.orderList.map(listItem => {
            return <OrderListItem
                key={listItem.id}
                listItem={listItem} />
        });

        return <ul className="order_list">{list}</ul>;
    }
};

// Make global state available in props
const mapStateToProps = state => ({...state});

export default connect(mapStateToProps)(OrderList);