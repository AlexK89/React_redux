import React, {Component} from 'react';
import { connect } from 'react-redux';
import * as actions from "../../store/actions";
import OrderList from './OrderList/OrderList';

class Cart extends Component {
    render() {
        return (
            <div className="cart">
                <OrderList />
                <div className="checkout">
                    <p className="checkout__total">$ {this.props.total}</p>
                    <div className="buttons">
                        <button className="buttons__reset" onClick={this.props.resetQuantity}>Clear</button>
                        <button className="buttons__submit">Check out</button>
                    </div>
                </div>
            </div>
        );
    }
}

// Make global state available in props
const mapStateToProps = state => ({...state});

// Send changed values to global state
const mapDispatchToProps = dispatch => ({resetQuantity: () => dispatch(actions.resetQuantity())});

export default connect(mapStateToProps, mapDispatchToProps)(Cart);