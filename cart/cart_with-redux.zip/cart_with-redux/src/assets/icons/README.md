# Icons

If you want to use any SVGs as icons, webpack will compile them from here...

You can reference this directory using the alias `'@icons'`, like so:

```
import pacman from '@icons/pacman.svg'
```
