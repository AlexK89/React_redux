export default {
  test: /\.html$/,
  use: { loader: 'html-loader' }
}
